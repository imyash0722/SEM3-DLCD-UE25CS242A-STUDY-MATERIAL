module circuit3(
    input A2,
    input B2,
    input C2,
    output Z
);

assign Z = (A2 | (B2 & C2)) | (A2 & B2);

endmodule
