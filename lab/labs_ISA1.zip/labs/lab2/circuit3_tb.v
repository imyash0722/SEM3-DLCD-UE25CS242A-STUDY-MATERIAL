module circuit3_tb;

reg A2, B2, C2;

wire Z;

circuit3 uut (
    .A2(A2),
    .B2(B2),
    .C2(C2),
    .Z(Z)
);

initial begin
    $dumpfile("circuit3.vcd");
    $dumpvars(0, circuit3_tb);

    $monitor($time,
        " A2=%b B2=%b C2=%b | Z=%b",
        A2, B2, C2, Z
    );

    A2=0; B2=0; C2=0;
    #100 A2=0; B2=0; C2=1;
    #100 A2=0; B2=1; C2=0;
    #100 A2=0; B2=1; C2=1;
    #100 A2=1; B2=0; C2=0;
    #100 A2=1; B2=0; C2=1;
    #100 A2=1; B2=1; C2=0;
    #100 A2=1; B2=1; C2=1;

    #100 $finish;
end

endmodule
