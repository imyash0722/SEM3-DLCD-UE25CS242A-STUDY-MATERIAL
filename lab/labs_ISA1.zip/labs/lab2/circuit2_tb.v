module circuit2_tb;

reg A, B, C;

wire Y;

circuit2 uut (
    .A(A),
    .B(B),
    .C(C),
    .Y(Y)
);

initial begin
    $dumpfile("circuit2.vcd");
    $dumpvars(0, circuit2_tb);

    $monitor($time,
        " A=%b B=%b C=%b | Y=%b",
        A, B, C, Y
    );

    A=0; B=0; C=0;
    #100 A=0; B=0; C=1;
    #100 A=0; B=1; C=0;
    #100 A=0; B=1; C=1;
    #100 A=1; B=0; C=0;
    #100 A=1; B=0; C=1;
    #100 A=1; B=1; C=0;
    #100 A=1; B=1; C=1;

    #100 $finish;
end

endmodule
