module circuit1(
    input A,
    input B,
    input C,
    output D,
    output E
);

assign D = (A & B) | (~C);
assign E = ~C;

endmodule
