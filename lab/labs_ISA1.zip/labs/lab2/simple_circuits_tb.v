module simple_circuits_tb;

reg A, B, C;
reg A2, B2, C2;

wire D, E, Y, Z;

simple_circuits uut (
    .A(A),
    .B(B),
    .C(C),
    .A2(A2),
    .B2(B2),
    .C2(C2),
    .D(D),
    .E(E),
    .Y(Y),
    .Z(Z)
);

initial begin
    $dumpfile("simple_circuits.vcd");
    $dumpvars(0, simple_circuits_tb);

    $monitor($time,
        " A=%b B=%b C=%b | D=%b E=%b | Y=%b | A2=%b B2=%b C2=%b | Z=%b",
        A, B, C, D, E, Y, A2, B2, C2, Z
    );

    A=0; B=0; C=0; A2=0; B2=0; C2=0;
    #100 A=0; B=0; C=1; A2=0; B2=0; C2=1;
    #100 A=0; B=1; C=0; A2=0; B2=1; C2=0;
    #100 A=0; B=1; C=1; A2=0; B2=1; C2=1;
    #100 A=1; B=0; C=0; A2=1; B2=0; C2=0;
    #100 A=1; B=0; C=1; A2=1; B2=0; C2=1;
    #100 A=1; B=1; C=0; A2=1; B2=1; C2=0;
    #100 A=1; B=1; C=1; A2=1; B2=1; C2=1;

    #100 $finish;
end

endmodule