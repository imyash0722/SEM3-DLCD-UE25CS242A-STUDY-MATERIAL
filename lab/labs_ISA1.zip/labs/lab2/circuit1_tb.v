module circuit1_tb;

reg A, B, C;

wire D, E;

circuit1 uut (
    .A(A),
    .B(B),
    .C(C),
    .D(D),
    .E(E)
);

initial begin
    $dumpfile("circuit1.vcd");
    $dumpvars(0, circuit1_tb);

    $monitor($time,
        " A=%b B=%b C=%b | D=%b E=%b",
        A, B, C, D, E
    );

    A=0; B=0; C=0;
    #100 A=0; B=0; C=1;
    #100 A=0; B=1; C=0;
    #100 A=0; B=1; C=1;
    #100 A=1; B=0; C=0;
    #100 A=1; B=0; C=1;
    #100 A=1; B=1; C=0;
    #100 A=1; B=1; C=1;

    #100 $finish;
end

endmodule
