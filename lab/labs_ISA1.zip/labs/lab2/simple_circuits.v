module simple_circuits(
    input A,
    input B,
    input C,
    input A2,
    input B2,
    input C2,
    output D,
    output E,
    output Y,
    output Z
);

assign D = (A & B) | (~C);
assign E = ~C;

assign Y = A | (B & C);

assign Z = (A2 | (B2 & C2)) | (A2 & B2);

endmodule