module fa(a, b, cin, s, cout);
    input  a, b, cin;
    output s, cout;

    assign s    = a ^ b ^ cin;
    assign cout = (a & b) | (b & cin) | (a & cin);
endmodule

module alu_slice(i0, i1, op, cin, o, cout);
    input  i0, i1;
    input  [1:0] op;
    input  cin;
    output o, cout;

    wire and_out, or_out, fa_out;
    wire b;

    assign b = i1 ^ op[0];

    assign and_out = i0 & i1;
    assign or_out  = i0 | i1;

    fa FA(i0, b, cin, fa_out, cout);

    assign o = op[1] ? (op[0] ? or_out : and_out) : fa_out;
endmodule

module alu(i0, i1, op, o, carry, overflow);
    input  [15:0] i0, i1;
    input  [1:0]  op;
    output [15:0] o;
    output carry, overflow;

    wire c1,  c2,  c3,  c4,  c5,  c6,  c7,
         c8,  c9,  c10, c11, c12, c13, c14, c15;

    alu_slice S0  (i0[0],  i1[0],  op, op[0], o[0],  c1);
    alu_slice S1  (i0[1],  i1[1],  op, c1,    o[1],  c2);
    alu_slice S2  (i0[2],  i1[2],  op, c2,    o[2],  c3);
    alu_slice S3  (i0[3],  i1[3],  op, c3,    o[3],  c4);
    alu_slice S4  (i0[4],  i1[4],  op, c4,    o[4],  c5);
    alu_slice S5  (i0[5],  i1[5],  op, c5,    o[5],  c6);
    alu_slice S6  (i0[6],  i1[6],  op, c6,    o[6],  c7);
    alu_slice S7  (i0[7],  i1[7],  op, c7,    o[7],  c8);
    alu_slice S8  (i0[8],  i1[8],  op, c8,    o[8],  c9);
    alu_slice S9  (i0[9],  i1[9],  op, c9,    o[9],  c10);
    alu_slice S10 (i0[10], i1[10], op, c10,   o[10], c11);
    alu_slice S11 (i0[11], i1[11], op, c11,   o[11], c12);
    alu_slice S12 (i0[12], i1[12], op, c12,   o[12], c13);
    alu_slice S13 (i0[13], i1[13], op, c13,   o[13], c14);
    alu_slice S14 (i0[14], i1[14], op, c14,   o[14], c15);
    alu_slice S15 (i0[15], i1[15], op, c15,   o[15], carry);

    assign overflow = c15 ^ carry;
endmodule
