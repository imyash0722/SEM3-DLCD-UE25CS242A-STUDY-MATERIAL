`define TESTVECS 16

module tb_alu;
    reg  [15:0] i0, i1;
    reg  [1:0]  op;
    wire [15:0] o;
    wire        carry, overflow;

    wire signed [15:0] si0, si1, so;
    assign si0 = i0;
    assign si1 = i1;
    assign so  = o;

    alu uut(
        .i0(i0),
        .i1(i1),
        .op(op),
        .o(o),
        .carry(carry),
        .overflow(overflow)
    );

    initial begin
        $dumpfile("tb_alu.vcd");
        $dumpvars(0, tb_alu);
    end

    initial begin
        $monitor($time, " op=%b i0=%d i1=%d | o=%d carry=%b overflow=%b",
                 op, si0, si1, so, carry, overflow);

        #0  op = 2'b00; i0 = 16'd0;     i1 = 16'd0;
        #20 op = 2'b00; i0 = 16'd15;    i1 = 16'd10;
        #20 op = 2'b00; i0 = 16'd32767; i1 = 16'd1;
        #20 op = 2'b00; i0 = 16'hFFFF;  i1 = 16'd1;

        #20 op = 2'b01; i0 = 16'd10;    i1 = 16'd3;
        #20 op = 2'b01; i0 = 16'd0;     i1 = 16'd0;
        #20 op = 2'b01; i0 = 16'd5;     i1 = 16'd10;
        #20 op = 2'b01; i0 = 16'h8000;  i1 = 16'd1;

        #20 op = 2'b10; i0 = 16'hFF00;  i1 = 16'hF0F0;
        #20 op = 2'b10; i0 = 16'hAAAA;  i1 = 16'h5555;
        #20 op = 2'b10; i0 = 16'hFFFF;  i1 = 16'hFFFF;
        #20 op = 2'b10; i0 = 16'h1234;  i1 = 16'h5678;

        #20 op = 2'b11; i0 = 16'hFF00;  i1 = 16'h00FF;
        #20 op = 2'b11; i0 = 16'hAAAA;  i1 = 16'h5555;
        #20 op = 2'b11; i0 = 16'h0000;  i1 = 16'h0000;
        #20 op = 2'b11; i0 = 16'h1234;  i1 = 16'h5678;

        #20 $finish;
    end
endmodule
