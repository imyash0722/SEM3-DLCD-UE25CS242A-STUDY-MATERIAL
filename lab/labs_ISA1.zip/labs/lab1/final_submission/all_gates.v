module all_gates(
    output out_and,
    output out_or,
    output out_not,
    output out_nand,
    output out_nor,
    output out_xor,
    output out_xnor,
    input a,
    input b
);

assign out_and  = a & b;
assign out_or   = a | b;
assign out_not  = ~a;    
assign out_nand = ~(a & b);
assign out_nor  = ~(a | b);
assign out_xor  = a ^ b;
assign out_xnor = ~(a ^ b);

endmodule
