module all_gates_tb;
reg a, b;
wire out_and, out_or, out_not, out_nand, out_nor, out_xor, out_xnor;

all_gates uut(out_and, out_or, out_not, out_nand, out_nor, out_xor, out_xnor, a, b);

initial begin
    #0   a = 0; b = 0;
    #100 a = 0; b = 1;
    #100 a = 1; b = 0;
    #100 a = 1; b = 1;
end

initial begin
	$monitor($time, " a = %b, b = %b, out_and = %b, out_or = %b, out_not = %b, out_nand = %b, out_nor = %b, out_xor = %b, out_xnor = %b", a, b, out_and, out_or, out_not, out_nand, out_nor, out_xor, out_xnor);
end 

initial begin
    $dumpfile("all_gates.vcd");
    $dumpvars(0, all_gates_tb);
end
endmodule
