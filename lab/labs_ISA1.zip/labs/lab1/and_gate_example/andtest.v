module andtest;
  reg a, b;
  wire c;

  and2 u1(c, a, b);

  initial
  begin
    $dumpfile("firstdesign.vcd");
    $dumpvars(0, andtest);

    #0 a=0; b=0;
    #100 a=0; b=1;
    #100 a=1; b=0;
    #100 a=1; b=1;
    #100 $finish; 
  end

  initial
  begin
    $monitor($time, " a=%b, b=%b, c=%b", a, b, c);
  end
endmodule
