module basic_gates_tb;
    reg a;
    reg b;

    wire and_out, or_out, not_out, nand_out, nor_out, xor_out, xnor_out;

    basic_gates uut (
        .a(a), .b(b), 
        .and_out(and_out), .or_out(or_out), .not_out(not_out), 
        .nand_out(nand_out), .nor_out(nor_out), .xor_out(xor_out), .xnor_out(xnor_out)
    );

    initial begin
        $dumpfile("basic_gates.vcd");
        $dumpvars(0, basic_gates_tb);

        #0 a=0; b=0;
        #100 a=0; b=1;
        #100 a=1; b=0;
        #100 a=1; b=1;
        #100 $finish;
    end

    initial begin
        $monitor("%0d a=%b, b=%b | AND=%b OR=%b NOT=%b NAND=%b NOR=%b XOR=%b XNOR=%b", 
                  $time, a, b, and_out, or_out, not_out, nand_out, nor_out, xor_out, xnor_out);
    end
endmodule
