module ha(a, b, sum, cout);
input a, b;
output sum, cout;
assign sum  = a ^ b;
assign cout = a & b;
endmodule

module fa_c2(i0, i1, i2, sum, cout);
input i0, i1, i2;
output sum, cout;
assign sum  = i0 ^ i1 ^ i2;
assign cout = (i0 & i1) | (i1 & i2) | (i0 & i2);
endmodule

module gate_block(y1, s0, c0, and_out);
input y1, s0, c0;
output and_out;
wire not_y1;
assign not_y1  = ~y1;
assign and_out = not_y1 & s0 & c0;
endmodule

module circuit2(i, y, Sout, Cout);
input [2:0] i;
input [1:0] y;
output Sout, Cout;
wire s0, c0, and_wire;
fa_c2      M1(i[0], i[1], i[2], s0, c0);
gate_block M2(y[1], s0, c0, and_wire);
ha         M3(and_wire, y[0], Sout, Cout);
endmodule
