`define TESTVECS 32

module circuit2_tb;
reg [2:0] i;
reg [1:0] y;
wire Sout, Cout;
reg [4:0] test_vecs [0:31];
integer k;

circuit2 uut(i, y, Sout, Cout);

initial
begin
    for(k = 0; k < 32; k = k + 1)
    begin
        test_vecs[k] = k[4:0];
    end
end

initial
begin
    for(k = 0; k < `TESTVECS; k = k + 1)
    begin
        #20 {y, i} = test_vecs[k];
    end
    #20 $finish;
end

initial
begin
    $monitor($time, " y=%b, i=%b, Sout=%b, Cout=%b",
             y, i, Sout, Cout);
end

initial
begin
    $dumpfile("circuit2.vcd");
    $dumpvars(0, circuit2_tb);
end
endmodule
