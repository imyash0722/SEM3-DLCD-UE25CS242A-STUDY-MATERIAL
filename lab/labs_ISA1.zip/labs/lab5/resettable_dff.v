module resettable_dff(clk, in, reset, out);
input clk, in, reset;
output out;
wire df_in;

assign df_in = in & (~reset);

df D1(clk, df_in, out);

endmodule
