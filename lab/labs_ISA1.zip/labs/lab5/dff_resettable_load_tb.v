module dff_resettable_load_tb;
reg clk, in, load, reset;
wire out;

dff_resettable_load uut(clk, in, load, reset, out);

initial
begin
    clk = 1'b0;
    forever #5 clk = ~clk;
end

initial
begin
    $dumpfile("dff_resettable_load_test.vcd");
    $dumpvars(0, dff_resettable_load_tb);
    $monitor($time, " clk=%b, in=%b, load=%b, reset=%b, out=%b", clk, in, load, reset, out);
end

initial
begin
    #0  reset = 1'b1; load = 1'b1; in = 1'b0;
    #10 reset = 1'b0; load = 1'b0; in = 1'b1;
    #10 in = 1'b0;
    #10 in = 1'b1;
    #10 load = 1'b1; in = 1'b0;
    #10 in = 1'b1;
    #10 reset = 1'b1;
    #10 reset = 1'b0; load = 1'b0; in = 1'b1;
    #10 load = 1'b1;
    #10 $finish;
end

endmodule
