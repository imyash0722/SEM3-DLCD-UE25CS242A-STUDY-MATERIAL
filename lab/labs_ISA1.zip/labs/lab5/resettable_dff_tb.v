module resettable_dff_tb;
reg clk, in, reset;
wire out;

resettable_dff uut(clk, in, reset, out);

initial
begin
    clk = 1'b0;
    forever #5 clk = ~clk;
end

initial
begin
    $dumpfile("resettable_dff_test.vcd");
    $dumpvars(0, resettable_dff_tb);
    $monitor($time, " clk=%b, in=%b, reset=%b, out=%b", clk, in, reset, out);
end

initial
begin
    #0  reset = 1'b1; in = 1'b0;
    #10 reset = 1'b0; in = 1'b1;
    #10 in = 1'b0;
    #10 in = 1'b1;
    #10 reset = 1'b1;
    #10 reset = 1'b0; in = 1'b1;
    #10 in = 1'b0;
    #10 $finish;
end

endmodule
