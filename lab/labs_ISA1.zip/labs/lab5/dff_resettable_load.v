module dff_resettable_load(clk, in, load, reset, out);
input clk, in, load, reset;
output out;
wire mux_out;
wire d;

mux21 M1(out, in, load, mux_out);

assign d = mux_out & (~reset);

df D1(clk, d, out);

endmodule
