module dff_tb;
reg clk, in;
wire out;

df df_1(clk, in, out);

initial
begin
    clk = 1'b0;
    forever #5 clk = ~clk;
end

initial
begin
    $dumpfile("dff_test.vcd");
    $dumpvars(0, dff_tb);
    $monitor($time, " clk=%b, in=%b, out=%b", clk, in, out);
end

initial
begin
    #0  in = 1'b0;
    #10 in = 1'b1;
    #10 in = 1'b0;
    #10 in = 1'b1;
    #10 in = 1'b1;
    #10 in = 1'b0;
    #10 in = 1'b1;
    #10 in = 1'b0;
    #10 $finish;
end

endmodule
