module df(clk, in, out);
input clk, in;
output out;
reg df_out;

always @(posedge clk)
begin
    df_out <= in;
end

assign out = df_out;
endmodule
