module ripple_adder_tb;
    reg [3:0] a, b;
    reg cin;
    wire [3:0] s;
    wire cout;

    ripple_adder uut(
        .a(a),
        .b(b),
        .cin(cin),
        .s(s),
        .cout(cout)
    );

    initial begin
        $dumpfile("ripple_adder.vcd");
        $dumpvars(0, ripple_adder_tb);
    end

    initial begin
        $monitor($time, " a=%b b=%b cin=%b | s=%b cout=%b", a, b, cin, s, cout);

        #0  a = 4'b0000; b = 4'b0000; cin = 1'b0;
        #20 a = 4'b0000; b = 4'b0000; cin = 1'b1;
        #20 a = 4'b0000; b = 4'b0001; cin = 1'b0;
        #20 a = 4'b0000; b = 4'b0001; cin = 1'b1;
        #20 a = 4'b0001; b = 4'b0001; cin = 1'b0;
        #20 a = 4'b0001; b = 4'b0001; cin = 1'b1;
        #20 a = 4'b0010; b = 4'b0011; cin = 1'b0;
        #20 a = 4'b0010; b = 4'b0011; cin = 1'b1;
        #20 a = 4'b0101; b = 4'b0011; cin = 1'b0;
        #20 a = 4'b0101; b = 4'b0011; cin = 1'b1;
        #20 a = 4'b0111; b = 4'b0001; cin = 1'b0;
        #20 $finish;
    end
endmodule
